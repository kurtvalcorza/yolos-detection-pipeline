"""P2: cell 29's BYOD branches exec'd up to the first model call, through the path fields (BYOD_DATASET_DIR,
BYOD_IMAGE_PATH) and through the upload helper with a google.colab stand-in. Dataset cases: minimal 2 records,
a '..' file name, an absent image file, a label outside BYOD_CLASS_NAMES, an annotations.json that is a dict,
a box outside its image, an empty upload. Image cases: a text file, an empty upload."""
import io, json, os, sys, types, importlib, tempfile, contextlib
from pathlib import Path
import numpy as np
from PIL import Image
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('yolos_detection_pipeline'); pkg.__path__ = [str(repo / 'src/yolos_detection_pipeline')]
sys.modules['yolos_detection_pipeline'] = pkg
P = importlib.import_module('yolos_detection_pipeline.pipeline')
S = importlib.import_module('yolos_detection_pipeline.samples')
nb = json.loads((repo / 'tutorials/yolos_detection_colab.ipynb').read_text())
c29 = next(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'code' and 'USE_BYOD_DATASET = False' in ''.join(c['source']))
ds_code = c29.split('if USE_BYOD_DATASET:\n', 1)[1].split('    byod_pipe = ', 1)[0]
ds_code = '\n'.join(l[4:] for l in ds_code.splitlines())
img_code = c29.split('if USE_BYOD_IMAGE:\n', 1)[1].split('    byod_result = ', 1)[0]
img_code = '\n'.join(l[4:] for l in img_code.splitlines())
helper = c29.split('BYOD_DIR = ', 1)[1].split('\nif USE_BYOD_IMAGE', 1)[0]
helper = 'BYOD_DIR = ' + helper
def make_dir(entries, images, extra=None):
    d = Path(tempfile.mkdtemp())
    for name, size in images.items():
        Image.fromarray(np.random.default_rng(len(name)).integers(0, 255, (size[1], size[0], 3), dtype=np.uint8)).save(d / name)
    (d / 'annotations.json').write_text(json.dumps(entries) if extra is None else extra)
    return d
base_g = lambda: {**{k: getattr(P, k) for k in ('validate_inputs', 'validate_dataset', 'read_detection_records')}, 'split_dataset': S.split_dataset,
                  'Path': Path, 'Image': Image, 'EPOCHS': 10, 'HOLDOUT': 0.25, 'SEED': 0, 'threshold': 0.9, 'json': json, 'OUTPUTS': Path(tempfile.mkdtemp())}
def run_ds(dir_value, names='', upload=None):
    g = base_g(); g.update(BYOD_DATASET_DIR=str(dir_value) if dir_value else '', BYOD_CLASS_NAMES=names)
    if upload is not None:
        colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda: dict(upload))
        sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    try:
        with contextlib.redirect_stdout(io.StringIO()) as buf:
            exec(helper, g); exec(ds_code, g)
        return {'outcome': 'reached fine-tune stage', 'records': len(g['byod_records']), 'split': [len(g['byod_train']), len(g['byod_held'])], 'class_names': g['byod_names'], 'findings': g['byod_manifest']['findings']}
    except BaseException as exc:
        return {'outcome': 'refused', 'error': f'{type(exc).__name__}: {exc}'[:220]}
def run_img(path_value, upload=None):
    g = base_g(); g.update(BYOD_IMAGE_PATH=str(path_value) if path_value else '')
    if upload is not None:
        colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda: dict(upload))
        sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            exec(helper, g); exec(img_code, g)
        return {'outcome': 'accepted', 'size': list(g['byod_image'].size)}
    except BaseException as exc:
        return {'outcome': 'refused', 'error': f'{type(exc).__name__}: {exc}'[:220]}
ok2 = [{'file': 'a.png', 'boxes': [[10, 10, 50, 50]], 'labels': ['cat']}, {'file': 'b.png', 'boxes': [[5, 5, 40, 60]], 'labels': ['dog']}]
imgs = {'a.png': (64, 64), 'b.png': (64, 64)}
res = {'dataset': {
  'minimal_2_records_by_path': run_ds(make_dir(ok2, imgs)),
  'dotdot_file_name': run_ds(make_dir([{**ok2[0], 'file': '../a.png'}, ok2[1]], imgs)),
  'image_file_absent': run_ds(make_dir(ok2, {'a.png': (64, 64)})),
  'label_outside_BYOD_CLASS_NAMES': run_ds(make_dir(ok2, imgs), names='cat'),
  'class_name_with_no_box': run_ds(make_dir(ok2, imgs), names='cat,dog,bird'),
  'annotations_is_dict': run_ds(make_dir(None, imgs, extra='{"a": 1}')),
  'box_outside_image': run_ds(make_dir([{**ok2[0], 'boxes': [[10, 10, 500, 50]]}, ok2[1]], imgs)),
  'empty_upload_dialog': run_ds('', upload={}),
}, 'image': {
  'text_file_by_path': run_img((lambda p: (p.write_text('hi'), p)[1])(Path(tempfile.mkdtemp()) / 'x.png')),
  'empty_upload_dialog': run_img('', upload={}),
}}
print(json.dumps(res, indent=1)); (out / 'p2.json').write_text(json.dumps(res, indent=1))
