"""P1: rebuild the 40-image sign dataset (seed 0) and the 30/10 split with the carried samples.py, validate it with
the carried validate_dataset, and score a non-neural 'slot prior' with the carried average_precision on the 10
held-out images: the generator places every sign at one of six fixed grid slots (+/-28 px jitter, radius 46-70),
so predicting a fixed box of the median radius at every slot, for every class, measures how much of the task
the layout alone gives away. Also recompute the class balance of the held-out split."""
import json, sys, types, importlib
from collections import Counter
from pathlib import Path
import numpy as np
repo, out = Path(sys.argv[1]), Path(sys.argv[2])
pkg = types.ModuleType('yolos_detection_pipeline'); pkg.__path__ = [str(repo / 'src/yolos_detection_pipeline')]
sys.modules['yolos_detection_pipeline'] = pkg
P = importlib.import_module('yolos_detection_pipeline.pipeline')
S = importlib.import_module('yolos_detection_pipeline.samples')
records = S.sign_dataset(40, seed=0)
man = P.validate_dataset(records, S.SIGN_CLASSES, epochs=10)
train, held = S.split_dataset(records, train_fraction=0.75, seed=0)
res = {'n_records': man['n_records'], 'n_boxes': man['n_boxes'], 'boxes_per_class': man['boxes_per_class'],
       'split': {'train': len(train), 'held_out': len(held)}, 'train_boxes': sum(len(r['boxes']) for r in train),
       'held_out_boxes': sum(len(r['boxes']) for r in held), 'held_out_per_class': dict(Counter(l for r in held for l in r['labels'])),
       'record_2026_09_25': {'n_boxes': 82, 'per_class': {'stop-sign': 21, 'yield-sign': 34, 'speed-limit-sign': 27}, 'train_boxes': 65, 'held_out_boxes': 17,
                             'baseline_untrained_head': {'ap': 0.1118, 'ap50': 0.2123, 'per_class_ap50': {'stop': 0.0, 'yield': 0.0331, 'speed-limit': 0.604}},
                             'adapted': {'ap': 0.9043, 'ap50': 1.0, 'ap75': 1.0}}}
# box geometry actually produced, to choose the prior from the TRAINING split only
cent = [((b[0] + b[2]) / 2, (b[1] + b[3]) / 2, (b[2] - b[0]), (b[3] - b[1])) for r in train for b in r['boxes']]
w_med, h_med = float(np.median([c[2] for c in cent])), float(np.median([c[3] for c in cent]))
slots = [(x, y) for y in (150, 400) for x in (140, 360, 560)]
def snap(cx, cy):  # the slot centres as they appear in the training boxes (median per slot)
    return min(slots, key=lambda s: (s[0] - cx) ** 2 + (s[1] - cy) ** 2)
by_slot = {}
for cx, cy, w, h in cent:
    by_slot.setdefault(snap(cx, cy), []).append((cx, cy))
centres = {s: (float(np.median([p[0] for p in v])), float(np.median([p[1] for p in v]))) for s, v in by_slot.items()}
preds = []
for r in held:
    dets = []
    for s, (cx, cy) in centres.items():
        for name in S.SIGN_CLASSES:
            dets.append({'label': name, 'score': 0.5, 'box': [cx - w_med / 2, cy - h_med / 2, cx + w_med / 2, cy + h_med / 2]})
    preds.append(dets)
ap = P.average_precision(preds, held, S.SIGN_CLASSES)
res['slot_prior_baseline'] = {k: (round(v, 4) if isinstance(v, float) else v) for k, v in ap.items() if k in ('ap', 'ap50', 'ap75')}
res['slot_prior_baseline']['per_class_ap50'] = {k: round(v, 4) for k, v in ap.get('per_class_ap50', {}).items()}
res['slot_prior_baseline']['note'] = 'label-agnostic: every slot box is emitted once per class at the same score, fitted on the training split only'
print(json.dumps(res, indent=1)); (out / 'p1.json').write_text(json.dumps(res, indent=1))
